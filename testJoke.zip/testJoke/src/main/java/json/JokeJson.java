package json;

public class JokeJson extends JsonTypeValue<JokeJsonValue> {
}
